package com.posts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostsApplicationTests {

	@Test
	void contextLoads() {
	}

}
